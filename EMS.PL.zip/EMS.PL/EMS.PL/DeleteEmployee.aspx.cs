﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;
namespace EMS.PL
{
    public partial class DeleteEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lbnUser.Text = "Welcome " + Session["user"];
                Master.LogoutVisible = true;
                Master.MenuVisible = true;
            }


        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int EmpID = Convert.ToInt32(txtEmpID.Text);
                int recordsAffected = EmployeeValidation.DeleteEmployee(EmpID);
                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Record Deleted successfully')</script>");
                }
                else
                {
                    throw new EmployeeException("Record NOT Deleted");
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}