﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    public partial class UpdateEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["user"].ToString();
                Master.LogoutVisible = true;
                Master.MenuVisible = true;
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                int empID = Convert.ToInt32(txtEmpID.Text);
                Employee emp = EmployeeValidation.SearchEmployee(empID);
                if (emp != null)
                {
                    txtName.Text = emp.EmployeeName;
                    txtPhone.Text = emp.Phone;
                    txtEmail.Text = emp.Email;
                    ddlLocation.SelectedItem.Text = emp.Location;
                }
                else
                {
                    string message = "Employee not found with id : " + empID;
                    throw new EmployeeException(message);
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Employee Emp= new Employee();
                Emp.EmployeeID = Convert.ToInt32(txtEmpID.Text);
                Emp.EmployeeName= txtName.Text;
                Emp.Phone= txtPhone.Text;
                Emp.Email=txtEmail.Text;
                Emp.Location=ddlLocation.SelectedItem.Text;
                int recordsAffected = EmployeeValidation.UpdateEmployee(Emp);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Record Updated successfully')</script>");
                }
                else
                {
                    throw new EmployeeException("Record Not Updated");
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }




        }
    }
}