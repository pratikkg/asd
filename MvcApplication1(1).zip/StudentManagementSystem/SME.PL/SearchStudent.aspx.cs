﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;
using SMS.Exception;
using SMS.BL;

namespace SME.PL
{
    public partial class SearchStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["user"].ToString();
                Master.LogoutVisible = true;
                Master.MenuVisible = true;
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try 
            {
                int studID = Convert.ToInt32(txtEmpID.Text);
                Student stud = StudentValidation.SearchStudent(studID);
                if (stud != null)
                {
                    gvStudent.DataSource = new List<Student>{stud};
                    gvStudent.DataBind();
                }
                else
                {
                    string message = "Student not found with id : " + studID;
                    throw new StudentException(message);
                }
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}