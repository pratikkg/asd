﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;
using SMS.Exception;
using SMS.BL;

namespace SME.PL
{
    public partial class InsertStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["user"];
                Master.LogoutVisible = true;
                Master.MenuVisible = true;
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                Student stud = new Student();
                stud.StudID = Convert.ToInt32(txtEmpID.Text);
                stud.StudName = txtName.Text;
                stud.Phone = txtPhone.Text;
                stud.Email = txtEmail.Text;
                stud.Location = ddlLocation.SelectedItem.Text;
                if (RadioButton1.Checked == true)
                    stud.Gender = "Male";
                else
                    stud.Gender = "Female";

                int recordsAffected = StudentValidation.InsertStudent(stud);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Record added successfully')</script>");
                }
                else
                {
                    throw new StudentException("Record Not added");
                }
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}