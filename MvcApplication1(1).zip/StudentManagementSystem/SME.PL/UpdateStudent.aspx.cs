﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;
using SMS.Exception;
using SMS.BL;

namespace SME.PL
{
    public partial class UpdateStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["user"].ToString();
                Master.LogoutVisible = true;
                Master.MenuVisible = true;
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                int studID = Convert.ToInt32(txtEmpID.Text);
                Student stud = StudentValidation.SearchStudent(studID);
                if (stud != null)
                {
                    txtName.Text = stud.StudName;
                    txtPhone.Text = stud.Phone;
                    txtEmail.Text = stud.Email;
                    ddlLocation.SelectedItem.Text = stud.Location;
                }
                else
                {
                    string message = "Student not found with id : " + studID;
                    throw new StudentException(message);
                }
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Student Stud = new Student();
                Stud.StudID = Convert.ToInt32(txtEmpID.Text);
                Stud.StudName = txtName.Text;
                Stud.Phone = txtPhone.Text;
                Stud.Email = txtEmail.Text;
                Stud.Location = ddlLocation.SelectedItem.Text;
                if (RadioButton1.Checked == true)
                    Stud.Gender = "Male";
                else
                    Stud.Gender = "Female";

                int recordsAffected = StudentValidation.UpdateStudent(Stud);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Record Updated successfully')</script>");
                }
                else
                {
                    throw new StudentException("Record Not Updated");
                }
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }




        }
    }
}