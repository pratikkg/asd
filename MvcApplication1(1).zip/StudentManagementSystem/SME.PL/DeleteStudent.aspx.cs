﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;
using SMS.Exception;
using SMS.BL;

namespace SME.PL
{
    public partial class DeleteStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lbnUser.Text = "Welcome " + Session["user"];
                Master.LogoutVisible = true;
                Master.MenuVisible = true;
            }


        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int studID = Convert.ToInt32(txtEmpID.Text);
                int recordsAffected = StudentValidation.DeleteStudent(studID);
                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Record Deleted successfully')</script>");
                }
                else
                {
                    throw new StudentException("Record NOT Deleted");
                }
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}