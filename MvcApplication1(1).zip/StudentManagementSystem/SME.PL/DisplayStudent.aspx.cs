﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.BL;
using SMS.Exception;
using SMS.Entity;
using System.Data;

namespace SME.PL
{
    public partial class DisplayStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["user"].ToString();
                Master.LogoutVisible = true;
                Master.MenuVisible = true;

                try
                {
                    DataTable dt = StudentValidation.DisplayStudent();
                    if (dt.Rows.Count > 0)
                    {
                        gvStudent.DataSource = dt;
                        gvStudent.DataBind();
                    }
                    else
                        throw new StudentException("Student Data not Available");
                }
                catch (StudentException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
                catch (SystemException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
            }
        }
    }
}