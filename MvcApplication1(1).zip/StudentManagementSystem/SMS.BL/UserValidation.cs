﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;
using SMS.Exception;
using SMS.DAL;

namespace SMS.BL
{
    public  class UserValidation
    {
        public static string ValidateUser(User user)
        {
            string userName = null;

            try
            {
                userName = UserOperation.ValidateLogin(user);
            }
            catch (UserException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userName;
        }

    }
}
