﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using SMS.Entity;
using SMS.Exception;
using SMS.DAL;

namespace SMS.BL
{
    public class StudentValidation
    {
        public static int InsertStudent(Student stud)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = StudentOperation.InsertStudent(stud);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateStudent(Student stud)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = StudentOperation.UpdateStudent(stud);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteStudent(int studID)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = StudentOperation.DeleteStudent(studID);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static DataTable DisplayStudent()
        {
            DataTable dt = null;

            try
            {
                dt = StudentOperation.DisplayStudent();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return dt;
        }

        public static Student SearchStudent(int studID)
        {
            Student stud = null;

            try
            {
                stud = StudentOperation.SearchStudent(studID);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }
    }
}
