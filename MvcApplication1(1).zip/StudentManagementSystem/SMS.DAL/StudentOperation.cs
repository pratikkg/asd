﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using SMS.Entity;
using SMS.Exception;

namespace SMS.DAL
{
    public class StudentOperation
    {
        public static int InsertStudent(Student stud)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "usp_InsertStudent_121785";

                cmd.Parameters.AddWithValue("@StudID", stud.StudID);
                cmd.Parameters.AddWithValue("@StudName", stud.StudName);
                cmd.Parameters.AddWithValue("@Phone", stud.Phone);
                cmd.Parameters.AddWithValue("@Email", stud.Email);
                cmd.Parameters.AddWithValue("@Location", stud.Location);
                cmd.Parameters.AddWithValue("@Gender", stud.Gender);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateStudent(Student stud)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "usp_UpdateStudent_115022";

                cmd.Parameters.AddWithValue("@StudID", stud.StudID);
                cmd.Parameters.AddWithValue("@StudName", stud.StudName);
                cmd.Parameters.AddWithValue("@Phone", stud.Phone);
                cmd.Parameters.AddWithValue("@Email", stud.Email);
                cmd.Parameters.AddWithValue("@Location", stud.Location);
                cmd.Parameters.AddWithValue("@Gender", stud.Gender);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteStudent(int studID)
        {
            int recordAffected = 0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "usp_DeleteStudent_121785";
                  cmd.Parameters.AddWithValue("@StudID", studID);

                cmd.Connection.Open();
                recordAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordAffected;
        }

        public static DataTable DisplayStudent()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "usp_DisplayStudent";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt.Load(dr);
                }
                else
                {
                    throw new StudentException("Student Data not Available");
                }
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return dt;
        }

        public static Student SearchStudent(int studID)
        {
            Student stud = null;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "usp_SearchStudent_121785";

                cmd.Parameters.AddWithValue("@StudID", studID);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    stud = new Student();
                    stud.StudID = Convert.ToInt32(dr["StudID"]);
                    stud.StudName = dr["StudName"].ToString();
                    stud.Phone = dr["Phone"].ToString();
                    stud.Email = dr["Email"].ToString();
                    stud.Location = dr["Location"].ToString();
                    stud.Gender = dr["Gender"].ToString();
                }
                else
                {
                    throw new StudentException("Student not found with id" + studID);
                }
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }
    }
}
