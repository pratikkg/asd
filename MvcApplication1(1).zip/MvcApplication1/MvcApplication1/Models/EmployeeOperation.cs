﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication1.Models
{
    public class EmployeeOperation
    {
        public static List<Employee> empList = new List<Employee>();

        static EmployeeOperation()
        {
            empList.Add(new Employee() { EmployeeId = 1, Name = "Pratik", Salary = 1000, City = "Mumbai" });
            empList.Add(new Employee() { EmployeeId = 2, Name = "Rahul", Salary = 2000, City = "Mumbai" });
            empList.Add(new Employee() { EmployeeId = 3, Name = "Kiran", Salary = 3000, City = "Chennai" });
            empList.Add(new Employee() { EmployeeId = 4, Name = "Neha", Salary = 1000, City = "Pune" });
            empList.Add(new Employee() { EmployeeId = 5, Name = "Sam", Salary = 4000, City = "Bangalore" });
            empList.Add(new Employee() { EmployeeId = 6, Name = "Marmik", Salary = 8000, City = "Pune" });
            empList.Add(new Employee() { EmployeeId = 7, Name = "Pritesh", Salary = 7000, City = "Bangalore" });
            empList.Add(new Employee() { EmployeeId = 8, Name = "Vishal", Salary = 14000, City = "Mumbai" });
            empList.Add(new Employee() { EmployeeId = 9, Name = "Ashish", Salary = 21000, City = "chennai" });
            empList.Add(new Employee() { EmployeeId = 10, Name = "Vikram", Salary = 51000, City = "Pune" });
        }
    }
}